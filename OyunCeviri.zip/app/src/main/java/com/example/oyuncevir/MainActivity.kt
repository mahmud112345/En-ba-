package com.example.oyuncevir

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.BLACK)
        }
        val info = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            text = "Oyun Çeviri\n\n" +
                "1) Önce 'Üstte gösterme izni' ver.\n" +
                "2) 'Başlat'a bas, ekran yakalamaya izin ver.\n" +
                "3) PS Remote Play'i aç. Üstteki küçük panelden 'Bölge'ye bas, " +
                "yazının çıktığı yeri parmağınla çiz.\n" +
                "4) Çeviri ekranın üstünde görünür. ↕ ile alta alabilirsin.\n\n" +
                "İlk açılışta çeviri modeli indirilir (internet gerekir)."
        }
        val btnOverlay = Button(this).apply {
            text = "1) Üstte gösterme izni"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "İzin zaten verilmiş", Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }
        val btnStart = Button(this).apply {
            text = "2) Başlat"
            setOnClickListener { start() }
        }
        val btnStop = Button(this).apply {
            text = "Durdur"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).setAction("STOP"))
            }
        }
        root.addView(info)
        root.addView(btnOverlay)
        root.addView(btnStart)
        root.addView(btnStop)
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce üstte gösterme iznini ver", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Başladı. Şimdi PS Remote Play'i aç", Toast.LENGTH_LONG).show()
        }
    }
}
